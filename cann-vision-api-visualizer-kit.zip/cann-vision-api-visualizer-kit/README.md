# CANN Vision API Visualizer｜可移植交付包

本包可以离线运行 CANN Vision 的静态页面，也包含用于扩展/审查 API 可视化的 `ascend-c-api-visualizer` Codex skill。它不依赖 npm、CANN 或昇腾硬件。

## 目录

```text
app/
  cann-vision/                 页面与本地素材
  vendor/pto-design-system/    页面实际加载的最小运行时子集
skill/
  ascend-c-api-visualizer/     可安装的 Codex skill，含必要设计规范与案例参考
```

`app/cann-vision/index-light.html` 是入口。该页面的本地 CSS、JavaScript、图标和所需 PTO pattern 都在包内；官方 API 文档链接仍需要浏览器联网。

## 运行页面

解压后，在本包根目录执行以下一条命令，然后打开终端显示的本地地址：

```bash
python3 -m http.server 8000 --directory app
```

不要把 `cann-vision` 单独移动出来：它通过 `../vendor/pto-design-system/` 引用同级的最小设计系统运行时。

## 安装 Skill

将 `skill/ascend-c-api-visualizer` 整个目录复制到收件人 Codex 的 skills 目录（默认是 `~/.codex/skills/`；如设置了 `CODEX_HOME`，则为 `$CODEX_HOME/skills/`），随后新开一个 Codex task。

使用 skill 修改页面时，建议将本包作为该 task 的工作区，并明确让 Codex 编辑 `app/cann-vision/index-light.html`。skill 已不再依赖原项目的绝对目录或单独安装 PTO design-system skill。

## 已知边界

- 页面内“在 V4 深检目标模型”链接指向原仓库未包含的 `recommendation-trace-V4.html`，在此精简包中不会打开目标页；其余页面功能不受影响。
- 本包仅包含当前页面运行所需的 8 个 PTO pattern。若要新建依赖其他 PTO pattern 的页面，请改用完整设计系统，而不是在本包中临时复制样式。
- 对外发放前，请确认 `pto-design-system` 的代码、图标和视觉资产具备再分发授权；当前源目录未发现许可证文件。
