# 当前案例反向规格

权威实现：目标工作区中的 `cann-vision/index-light.html`；本配送包的默认路径是 `app/cann-vision/index-light.html`。

当前 API selector 有 Load3D、Gm2UbAlign 和 Add。可作为“同等完成度”黄金案例的是 Load3D 与 `asc_copy_gm2ub_align`；Add 是较早的轻量 block 读写示例，可作为元素级计算范式参考，但不能单独代表新案例的完整交付标准。

## 共同骨架

两个黄金案例都包含：

1. 单一 API state；
2. 将 state 转为参数对象或 derived context 的纯计算；
3. 由 derived context 构造可视化 scene；
4. 由同一 context 生成说明、公式、timeline 和代码；
5. 典型预设与手动参数联动；
6. API 切换时的 timer、playback、controller 生命周期管理；
7. PTO `ide-frame`、`matrix-canvas`、`tensor-volume-canvas`、`floating-playback-control` 的 direct embedding。

## Load3D：布局变换 / 滑窗采样范式

### 状态与派生

- 输入 state：`H`、`W`、`Ci`、`C0`、filter、stride、四向 padding、padValue、dilation、repeatMode、repeatTime、jumpStride、channel padding visibility。
- `load3dShape` 计算 effective kernel、`Ho`、`Wo`、`C1`、物理通道槽、padding channels 和 A2 逻辑矩阵尺寸。
- `load3dPatches` 建立 `oh/ow → kh/kw/c → srcH/srcW → A2 row/col` 的逐元素映射，并标记 padding 来源。
- 播放单位不是单 element，而是一个采样位置 `(kh, kw)` 下沿 C 轴的一组值。这是 UX 模型，应与硬件微指令时序区分。

### 视图映射

- NCHW 输入：`tensor-volume-canvas`，强调原始空间窗口。
- NC1HWC0 A1：`tensor-volume-canvas`，强调空间 padding、C0 padding、dilation 跳过位置和当前采样。
- A2：`matrix-canvas`，强调输出行、当前 `(kh, kw)` 对应列区间、已写入和 PAD 来源。
- Inspector：展示当前输出位置、窗口左上角、采样位置、C1/物理通道与坐标公式。

### 联动不变量

- `Ho = floor((Hi + padTop + padBottom - effectiveKernelH) / strideH) + 1`；W 轴同理。
- `effectiveKernel = (kernel - 1) * dilation + 1`。
- `C1 = ceil(Ci / C0)`，物理通道 padding 不应进入 A2 的逻辑列数。
- A2 行数为 `Ho * Wo`；逻辑列数为 `Hk * Wk * Ci`。
- 当前可视状态、播放标签、Inspector 与生成的 `LoadData3DParamsV1` 必须指向同一组参数与 step。

## asc_copy_gm2ub_align：搬运 / 对齐范式

### 状态与派生

- 支持连续搬运和高维切分两个函数形态。
- 输入 state：form、dtype、size、nBurst、lenBurst、srcStride、dstStride、左右 padding、constant pad、L2 cache mode 和 padValue。
- `gm2ubContext` 同时保存 requested input 与 effective layout 计算：element bytes、valid bytes、src/dst total bytes、compact/normal、per-block aligned footprint、source/destination segments 和 warnings。
- timeline 由 ready、transfer、pad/align、final 组成；高维模式按 block 展开。

### 视图映射

- GM 与 UB 都用 `matrix-canvas` 表示统一地址空间尺度。
- GM 标出 valid segment 和 stride gap；UB 标出 valid write、left/right padding、alignment padding 和已完成块。
- 当前 transfer 在两端使用相同 selected 状态，明确“一次搬运的源与目标”。
- 说明区同步展示 valid bytes、physical footprint、compact/normal 与 32B 对齐公式。

### 联动不变量

- dtype 决定 element bytes，并影响 padding elements 到 bytes 的换算及每行 lane 数。
- `validBytes = nBurst * lenBurst`。
- source footprint 由相邻 block 起始地址距离决定，不等于 valid bytes。
- compact 模式只有整体 packed result 做尾部对齐；normal 模式每个 block 有独立物理 footprint。
- `l2_cache_mode` 不改变矩阵几何，但必须改变生成代码或解释。
- 当 requested `dst_stride` 不足时，不能把 effective stride 静默当作用户输入；新案例必须同时显示 requested、effective 和修正规则，或直接拒绝非法值。

## 可复用但不应复制的内容

- 可复用：API selector 结构、参数分组语法、代码复制/预览、共享 playback、scene contract、controller lifecycle。
- 不应复制：Load3D 坐标公式、GM↔UB segment 算法、案例私有 DOM/CSS、某个 API 的预设数字。
- 新案例若反复需要新的 renderer 能力，应把业务无关部分提升为 PTO pattern，而不是继续把 Canvas 逻辑堆入单页 HTML。
