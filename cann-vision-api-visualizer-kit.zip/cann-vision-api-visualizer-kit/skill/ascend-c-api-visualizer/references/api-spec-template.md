# API Visualizer 规格卡模板

为每个新 API 建一份规格卡。未知项写 `unresolved`，不要用看起来合理的数值补齐。

## 1. 身份与证据

| 字段 | 内容 |
|---|---|
| Case key | 代码内稳定键名 |
| API / 函数族 | 官方名称 |
| 文档标题与 URL | 一手来源 |
| 文档版本 / 日期 |  |
| CANN 版本 |  |
| 适用 SoC |  |
| Header / namespace |  |
| 访问日期 |  |
| 其他一手来源 | 头文件、样例、测试、源码 |

## 2. 函数原型与重载

逐个记录需要支持的函数原型、模板参数、重载选择条件。原样保留官方参数名，避免先改成产品命名后丢失映射。

## 3. 数据对象

| 对象 | 角色 | memory scope | dtype | logical shape | physical format / layout | 地址单位 |
|---|---|---|---|---|---|---|
| src | input |  |  |  |  |  |
| dst | output |  |  |  |  |  |

## 4. 参数字典

| 参数 | 类型 | 单位 | 合法域 | 示例/默认 | 作用对象 | 影响维度 | 条件启用 | 证据状态 |
|---|---|---|---|---|---|---|---|---|
|  |  | elements / bytes / blocks / enum / bool |  |  |  | shape / address / layout / value / code-only |  | documented / unresolved |

`影响维度` 至少从以下维度中选择：

- logical shape
- physical shape / footprint
- source address mapping
- destination address mapping
- element value
- order / synchronization
- generated code only
- supported dtype / format / SoC

## 5. 语义公式

逐条记录并标明 `documented` 或 `derived`：

- 输出 shape；
- element ↔ byte 换算；
- stride 的定义（gap 还是相邻起点距离）；
- alignment 粒度与对齐作用域（整体、每 block、每 row）；
- padding 的位置、值来源和物理占用；
- logical index ↔ physical address；
- broadcast / reduce / window / tile 映射；
- 尾块、空输出和边界条件。

## 6. 参数依赖与合法性

| 条件 | 结果 | UI 行为 | 证据状态 |
|---|---|---|---|
|  | valid / warning / invalid | enable / disable / reject / normalize |  |

若使用 normalize，补充：

| requested | effective | 规则 | 用户可见解释 | 生成代码使用哪个值 |
|---|---|---|---|---|

## 7. 可视化问题与 pattern

| 用户问题 | 语义对象 | 视图/pattern | 编码 | 文本 fallback |
|---|---|---|---|---|
| 参数改变了什么？ |  |  |  |  |
| 数据从哪里到哪里？ |  |  |  |  |
| 当前 step 做什么？ |  |  |  |  |
| 哪些是有效数据、gap、padding 或生成值？ |  |  |  |  |

说明是否需要 playback。若需要，明确它表达的是 API 语义顺序还是 UX 分步，不宣称真实 duration。

## 8. 统一状态与派生输出

### Raw state

列出用户可编辑字段。

### Normalized state

列出类型、范围和 enum 归一化后的字段，仍保留 requested 值。

### Derived model

列出 shape、segments、addresses、footprint、warnings、validity、timeline 数据与 effective values。

### Scene adapters

列出每个共享 pattern 的 scene contract 映射。

## 9. 参数联动表

| 参数/操作 | 控件状态 | 公式/指标 | 可视化 | timeline | 说明/warning | 生成代码 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

填 `changes`、`no effect` 或 `not applicable`。不得留空来掩盖未实现联动。

## 10. 预设与测试矩阵

| 场景 | 教学目标 | 参数 | 预期派生结果 | 必须出现的视觉信号 | 代码差异 | 证据 |
|---|---|---|---|---|---|---|
| baseline |  |  |  |  |  |  |
| structural variant |  |  |  |  |  |  |
| boundary / invalid |  |  |  |  |  |  |

## 11. Unresolved ledger

| 问题 | 为什么重要 | 当前不做的假设 | 需要的证据 |
|---|---|---|---|
|  |  |  |  |

