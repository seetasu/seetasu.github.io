# 配送包中的 PTO design-system 摘要

这是 `ascend-c-api-visualizer` 的最小设计系统参考，不是完整 PTO design-system 的替代品。

## 当前页面的约束

- 完整页面保持 `ide-frame` 作为 shell；先消费已有 token、component class 和 pattern，页面只提供领域数据、pane 内容和 glue code。
- 不新造私有 button、toggle、badge、card、spacing、radius、shadow、border 或背景语言；不在业务页重写 pattern 的 geometry、DPR、resize、zoom、tooltip 或 playback chrome。
- 正文和说明使用 `--type-body`；紧凑 UI 不低于 12px；11px 仅用于短 micro label 或明确允许的数据可视化标注。
- `floating-playback-control` 仅用于真实 step / timeline 语义；API 可视化的离散播放允许使用它。
- 独立矩阵/张量卡片使用 `viz-container--matrix`，卡片左上角必须由 `tensor-title` 渲染；二维矩阵复用 `matrix-canvas`，三维 Tensor 复用 `tensor-volume-canvas`。

## 何时读哪些文件

- 新增或改变视觉布局：读 `DESIGN.md`、`quick-reference.md`、`patterns/patterns.json` 及目标 pattern 的 `pattern.json`。
- 把既有页面迁为 PTO：额外读 `retrofit-container-audit.md` 和 `pto-design-system-map.md`。
- 修改 `index-light.html` 中已有 API 案例：至少读 `patterns/ide-frame/pattern.json`、`patterns/tensor-title/pattern.json`，以及会实际调用的矩阵、Tensor 或播放 pattern contract。

配送包运行时的 pattern 源码在 `app/vendor/pto-design-system/`，而 `matrix-canvas`、`tensor-volume-canvas` 随 `app/cann-vision/patterns/` 一起分发。若工作需要本包未包含的 pattern，请使用完整设计系统；不要从其他业务页面复制私有样式。
