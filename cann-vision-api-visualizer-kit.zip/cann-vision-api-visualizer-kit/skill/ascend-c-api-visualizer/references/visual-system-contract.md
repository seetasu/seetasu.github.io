# API Visualizer 公共 UI 系统契约

## 定位

API 案例不是视觉系统。案例提供 API-specific state、字段内容、scene、timeline 和代码；公共系统提供区域骨架、控件密度、状态表现、字体、间距和响应式行为。

视觉 reference 的来源优先级：

1. PTO design-system tokens 与 pattern contract；
2. API Visualizer 公共 primitive；
3. 当前页面的共享组件实现；
4. 现有 API 案例仅用于验证内容和行为，不作为视觉母版。

可视化样板：目标工作区的 `cann-vision/api-visualizer-primitive-preview.html`（配送包默认路径为 `app/cann-vision/api-visualizer-primitive-preview.html`）。它用于审查 primitive 的职责、状态和密度，不替代共享 pattern 的生产实现。

## Primitive 目录

| 公共 primitive（英文标识） | 中文名称 | 推荐职责 | 典型内容 | 关键状态 |
|---|---|---|---|
| `viz-container` | 可视化容器 | Canvas / SVG / diagram 的统一承载区域 | title、meta、legend、renderer slot | default、empty、loading、warning |
| `viz-container--matrix` | 矩阵可视化卡片 | 一个矩阵/张量视图的独立背景卡片 | matrix header、canvas host、legend | default、empty、warning |
| `tensor-title` | 张量标题 | 矩阵/张量卡片左上角的结构化标题 | label、role、shape、dtype、format、memory、state、status | full、compact、current、warning |
| `api-selector` | API 案例选择器 | 当前 API / 案例切换 | select、doc link、note | default、hover、focus |
| `api-control-panel` | API 控件面板 | API 参数列的统一外壳 | API selector、groups、code actions | expanded、collapsed、scrollable |
| `api-control-group` | API 控件分组 | 一组相关参数的节奏 | heading、description、fields | default、warning |
| `api-field` | API 参数字段 | 单个参数字段 | label、help、input、unit | default、focus、disabled、invalid |
| `api-choice-group` | API 选项组 | 枚举/布尔选项 | radio / segmented options | selected、hover、focus、disabled |
| `api-preset-group` | API 预设场景组 | 可复用的教学场景切换 | preset buttons、description | selected、focus |
| `api-stepper` | API 数值步进器 | 数值参数输入 | minus、value、plus | min、max、disabled、invalid |
| `api-select` | API 下拉选择 | 参数枚举与策略选择 | select、option | default、hover、focus、disabled |
| `api-help` / `api-hint` | API 帮助提示 / 提示文本 | 单参数解释与组级说明 | tooltip、hint copy | default、focus、warning |
| `api-kv` / `api-kv-row` | API 键值检查器 / 键值行 | Inspector 派生信息 | label、value、unit、source | normal、emphasis、warning |
| `api-timeline` | API 语义时间线 | 语义步骤列表 | index、label、current state | upcoming、current、complete |
| `api-code-panel` | API 代码面板 | 原型与代码示例 | code、copy、preview | prototype、generated、copied |

这些名称是公共语义契约。实际 class 可以按 PTO design-system 的实现命名，但必须在 primitive map 中建立一一对应关系。

## Primitive map（实现前必填）

新增 API 之前先写一张表：

| 页面角色 | 使用的 primitive | domain wrapper | 允许覆盖 | 禁止覆盖 |
|---|---|---|---|---|
| API 切换 | `api-selector` | `.api-visualizer-selector` | options、文案、文档链接 | select 高度、箭头、surface |
| 参数列 | `api-control-panel` | `.asc-mmad-controls` | 内容、排序、状态 | panel fill、宽度、滚动、边框 |
| 控件组 | `api-control-group` + `api-field` | `.asc-mmad-group` | 参数名、单位、help | 字号、字段间距、输入皮肤 |
| 选项/预设 | `api-choice-group` + `api-preset-group` | `.asc-mmad-choice` | options、selected 状态 | button 高度、radius、状态色 |
| 数值/枚举 | `api-stepper` + `api-select` | `.asc-mmad-number` | value、min/max、options | 控件骨架、左右按钮尺寸 |
| 帮助/提示 | `api-help` + `api-hint` | `.asc-mmad-help` | tooltip、说明文案 | 自定义颜色、阴影、浮层皮肤 |
| 矩阵区 | `viz-container--matrix` + `tensor-title` + `matrix-canvas` | `.asc-mmad-matrix` | title scene、matrix scene、legend | 标题 DOM/CSS、Canvas geometry、grid、zoom |
| Inspector | `api-kv` | `.asc-mmad-inspector` | 字段值、warning | KV 列宽、行高、字体 |
| 代码 | `api-code-panel` | `.asc-mmad-code` | code text、action | toolbar / code surface skin |

矩阵区规则：每一个独立的矩阵/张量视图都必须是一个独立的 `viz-container--matrix` 卡片。Load3D 的 3 个视图对应 3 张卡片；GM→UB 的源矩阵与目标矩阵对应 2 张卡片；卡片之间的排列和间距由业务布局 wrapper 负责，不能把多个 canvas 合并到一个背景面板里。

张量标题规则：每张 `viz-container--matrix` 卡片左上角必须 direct embedding `tensor-title`，由 `PtoTensorTitle.render` 消费结构化 scene。矩阵卡片默认使用 `density: 'compact'`，避免标题挤压真实 cell 画布；只有容器宽高充足且信息任务需要时才使用 `full`。业务页面只提供字段与 host 布局，不复制标题 DOM/CSS、不覆盖 pattern 内部 class、不添加第二层 header/card；动态卡片销毁时同步销毁 controller。

矩阵粒度规则：默认优先调用 `matrix-canvas` 的 `createRealLayoutCells` 渲染真实 `1×1` cell；只有在同一视图内无法保持可读性时才使用 aggregate cell。当前 demo 的默认上限为同一视图所有矩阵均不超过 256 个逻辑 cell；例如 `16×16` 必须显示 256 个真实 cell。启用聚合时必须在标题/状态中标明“聚合 cell”，并使用共享语义轴尺度，禁止每个矩阵独立 auto-aggregate。

如果某个角色找不到 primitive，标记 `primitive-gap`，先补共享系统，不要直接在案例中造一个等价组件。

## 控件状态契约

每个 primitive 至少定义：

- default / hover / focus-visible / selected / disabled / invalid；
- label、help、unit 和 requested/effective 的信息层级；
- 键盘行为与 ARIA 语义；
- 最小字体和窄窗口行为；
- 是否允许 domain-specific emphasis。

控件的业务状态必须通过 data/state class 注入；不要用新的颜色、border 或 shadow 代替公共状态。

## 视觉验收

实现后在浏览器中对公共 primitive 做 parity check：

- computed `display`、`grid-template-columns`、`gap`、`padding`、`font`、`border`、`radius`、`background`；
- 标准宽度与窄窗口截图；
- light / dark 主题；
- hover、focus、selected、disabled、warning；
- 文案变长、数值变长、empty / NOP 状态。
- 每张矩阵/张量卡片的 `tensor-title` 与当前 shape、dtype、format、memory、step、真实/聚合状态一致，长 status 不挤压或溢出画布。

通过条件：同一 primitive 在不同 API 案例之间保持结构和密度一致；变化只能来自 domain content 和明确声明的状态，不来自案例私有 CSS。

Stepper 约束：`api-stepper` 必须沿用 `index-light.html` 的三列结构（左减号 / 中间值 / 右加号），字段默认采用“标签在上、控件在下”的纵向布局；不得为了样板页或单个案例改成标签与控件同一行。

## 如何判断 primitive 正确

不要只看 class 名称或一张“看起来差不多”的截图。至少要有三层证据：

1. **语义正确**：每个区域能映射到目录中的 primitive，`primitive map` 写清楚职责、domain wrapper 和禁止覆盖项。
2. **结构正确**：不同 API 案例使用相同 DOM 骨架与状态类；控件的键盘、ARIA、disabled、invalid 和 requested/effective 层级一致。
3. **视觉正确**：在 light / dark、标准 / 窄窗口、长文案和 warning 状态下，对同一 primitive 做 computed-style parity；允许变化只来自内容或明确声明的状态。

目标工作区的 `cann-vision/api-visualizer-primitive-preview.html` 是第三层验收的可视化样板。它能展示公共系统的目标形态，但不等同于已经把所有历史 API 案例迁移到共享实现。
