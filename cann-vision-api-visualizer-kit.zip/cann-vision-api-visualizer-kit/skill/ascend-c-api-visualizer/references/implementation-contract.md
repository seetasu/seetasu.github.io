# 实现与验收契约

## 推荐模块边界

现有页面是单文件实现，新案例可以继续集成进该页面，但逻辑上必须保持以下边界，避免复制一套彼此漂移的规则：

```text
case definition
  ├─ identity / docs / signatures
  ├─ state schema / controls / presets
  ├─ normalize(raw)
  ├─ derive(normalized)
  ├─ buildTimeline(derived)
  ├─ contextAtStep(derived, step)
  ├─ toScenes(derived, context)
  ├─ toExplanation(derived, context)
  └─ toCode(normalized, derived, context)

case registry
  ├─ selector item
  ├─ controls mount
  ├─ stage mount
  ├─ activate / deactivate
  └─ controller / timer cleanup
```

如果新增第三个以上同类案例仍需要复制 selector 分支、代码 action 定义或 timer cleanup，应先抽取 case registry，而不是继续扩张 `if/else`。

## 纯模型约束

- `derive`、`buildTimeline`、`contextAtStep` 不查询 DOM，不读取 Canvas，不依赖当前主题。
- 同一 normalized state 多次调用必须得到相同 derived model。
- scene adapter 只做业务模型到 pattern contract 的映射，不在 renderer 内补业务规则。
- generated code 使用与视觉模型相同的 requested/effective 决策。
- 公式字符串来自结构化派生值，不另写一套手算数字。
- 每个 timeline item 有稳定 id、phase、label 和关联语义对象；不要只用数组下标表达身份。

## 状态更新顺序

一次参数更新遵循：

```text
stop playback
→ update raw state
→ normalize
→ derive + validate
→ clamp/reset semantic step
→ update controls
→ update scenes
→ update timeline/current context
→ update metrics/explanation/warnings
→ update prototype/generated code
```

主题和 resize 只触发 renderer `resize`/重绘，不应重置 API state 或 playback step。

切换 API 时：停止旧 timer，隐藏或销毁旧 playback，调用 renderer `destroy`，取消旧案例监听或保证只绑定一次，然后激活新案例。

## Visualizer 范式与 PTO pattern

| 语义 | 首选 pattern | 案例负责 | pattern 负责 |
|---|---|---|---|
| 2D 地址/矩阵/布局 | `matrix-canvas` | extent、cell、状态、语义轴 | grid、clip、DPR、scroll/zoom、tooltip |
| 3D tensor 结构 | `tensor-volume-canvas` | extent、voxel、window/padding/current | 投影、深度排序、DPR、resize |
| 矩阵/张量标题 | `tensor-title` | label、shape、dtype、format、memory、state、status scene | 标题 DOM、字段编排、转义、byte formatting、full/compact density |
| 有序语义步骤 | `floating-playback-control` | timeline、timer、current context | playback chrome、scrubber、collapse |
| 页面 shell | `ide-frame` | 案例列表、参数、stage、说明 | chrome、pane、split、theme shell |

公共 UI primitive 采用语义 reference，而不是案例 reference：

| Primitive | 负责什么 | 案例可以提供什么 | 案例禁止提供什么 |
|---|---|---|---|
| `viz-container` / `viz-container--matrix` | 视觉区域和单矩阵卡片的布局、surface、标题/legend 插槽；默认优先真实 `1×1` cell（可用 `createRealLayoutCells` 生成） | domain title、scene、状态文案、cell 粒度状态 | 私有 card、边框、阴影、背景层；多个矩阵合并为一个背景面板；未达到可读性阈值就擅自聚合 |
| `tensor-title` | 每个矩阵/张量卡片左上角的结构化标题与状态 | title scene、host placement、controller lifecycle | 手写标题 DOM、复制/覆盖 pattern CSS、第二层 header/card、把业务规则塞进 renderer |
| `api-selector` / `api-control-panel` | API 案例选择、API 控件列的宽度、滚动、分组节奏 | options、controls schema、事件 glue | 自定义 panel chrome |
| `api-control-group` / `api-field` | 字段 label、help、输入布局 | 参数名、单位、说明 | 局部字号、列宽、padding |
| `api-choice-group` / `api-preset-group` / `api-stepper` | 选项、预设和数值输入的状态、键盘和密度 | 选项值、requested/effective 状态 | 新 button/toggle primitive |
| `api-select` / `api-help` / `api-hint` | 下拉枚举、参数帮助和组级提示的统一表现 | options、tooltip、hint copy | 私有提示气泡、状态色 |
| `api-kv` / `api-kv-row` | label/value 对齐、换行、metadata 字体 | 派生字段和数据格式化 | 重新定义 grid 列、行间距、背景 |
| `api-timeline` | step 行、当前/完成/未来状态 | timeline item、current step | 私有 playback chrome |
| `api-code-panel` | prototype/generated code 的容器与操作 | 代码文本、copy/preview action | 私有 code card、toolbar skin |

若公共 primitive 尚不存在，应先在共享 design-system / pattern 层定义并验证，再由 API 案例消费；不要从某个案例的私有 class 推导公共规范。

多 Matrix Tensor 同屏比较时，共享的是 semantic axis 的 source-unit scale，不是格子数。按 `matrix-canvas` contract 调用 `resolveSharedAggregateScale`、`createAggregateLayoutCells` 和 `synchronizeScale`。

## 模型级断言

至少为每个预设记录可复算断言。可以是自动测试，也可以是独立的开发断言函数；断言内容应验证业务不变量，不验证文案措辞。

建议覆盖：

- output logical shape；
- source/destination first、last address；
- valid elements / bytes；
- physical footprint；
- alignment / padding 数量；
- segment 不重叠或有意重叠；
- timeline step 数与顺序；
- current step 的 read/write set；
- generated code 中的 overload 与参数值；
- invalid state 的错误或 requested/effective 映射。

## 交互验收矩阵

| 验收项 | 通过条件 |
|---|---|
| 单参数变化 | 联动表声明为 changes 的每一路都更新，其他路明确 no effect |
| 组合参数 | 至少覆盖两个参数共同改变 shape/address 的情形 |
| 预设 | 一键载入，状态/图/代码一致；手改后取消预设选中 |
| 非法输入 | reject 或可见 normalize；无静默修正 |
| playback | prev/next/play/replay/scrubber/timeline 点击一致；离散步骤的 `Next` 在末步再次触发时循环回首步，自动播放到末步后停止，`Replay` 显式回首步 |
| primitive parity | 同一 primitive 在不同 API 案例中 computed style 一致；案例局部 CSS 只允许作用于 domain wrapper |
| API 切换 | 无旧 timer、旧高亮、旧 controller、旧文档链接残留 |
| code | 原型对应当前重载；生成调用使用当前值；复制/预览可用 |
| matrix granularity | 同一视图内所有矩阵均可读时渲染真实 cell（当前 demo 上限 256 个逻辑 cell）；超过上限才共享尺度聚合，并在 UI 中标记 aggregate |
| tensor title | 每个 `viz-container--matrix` 左上角由 `PtoTensorTitle.render` 渲染；矩阵卡片默认 compact，scene 随参数/step 更新，动态 DOM 替换前销毁旧 controller，无私有矩阵 header |
| 解释 | 单位、requested/effective、公式、warning 与图一致 |
| theme | light/dark 后 Canvas token 颜色刷新，状态不丢失 |
| resize | pane resize 后内容可读，无 canvas backing-store 模糊或裁切 |
| keyboard | radio/segmented、timeline step、code action 可键盘操作 |
| fallback | 隐藏标签仍有 tooltip、Inspector 或 live text 可读 |

## 文档忠实度 Gate

发布前逐项回答：

1. 是否支持了文档中真正影响主要语义的重载？若只支持子集，UI 是否明确？
2. 每个参数的单位是 elements、bytes、blocks 还是枚举？是否在控件与公式中一致？
3. stride 表示 gap 还是相邻起始地址距离？
4. alignment 作用于整体、每 block、每 row 还是每 transaction？
5. padding 是逻辑值、物理占位还是两者都有？值从哪里来？
6. dtype 是否改变 byte math、合法范围、布局或 overload？
7. format/shape 是否是 logical 还是 physical？两者是否混淆？
8. 芯片/CANN 版本限制是否被错误推广为通用行为？
9. 代码示例是否包含需要的配套 API、类型、enum 和初始化？
10. 哪些播放步骤属于 `ux-model` 而不是硬件事实？

任一关键问题无法回答时，将其写入 unresolved ledger；不要用 UI 动画掩盖语义缺口。

## 完成定义

案例只有在以下条件全部满足时才进入案例库：

- API 规格卡完成，关键字段无 unresolved；
- 纯派生模型可独立复算；
- baseline、structural variant、boundary/invalid 三类场景通过；
- 六路联动通过；
- PTO pattern contract 和 controller lifecycle 通过；
- 文档事实与 UX 模型在交付说明中可区分；
- 浏览器交互验证已执行，未验证项被明确记录。
