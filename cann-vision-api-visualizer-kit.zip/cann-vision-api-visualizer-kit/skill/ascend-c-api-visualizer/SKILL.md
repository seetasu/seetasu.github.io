---
name: ascend-c-api-visualizer
description: 将给定的 Ascend C / CANN API 文档转译为 CANN Vision API Visualizer 的参数联动案例。用于扩充案例库、复用公共 API Visualizer UI primitive，或审查一个 API 可视化是否忠实于文档；不用于证明真实硬件时序或性能。
---

# Ascend C API Visualizer

把 API 文档转成一个可验证的交互语义模型，再把模型映射到 PTO 可视化。核心链路是：

`文档证据 → API 规格卡 → 纯派生模型 → 场景适配器 → 联动 UI → 验收证据`

不要从复制某个既有案例的 HTML/CSS 开始。页面、解释、播放和生成代码必须消费同一个规范化状态与派生模型。

## 开始前

1. 读取用户提供的 API 文档全文，包括函数原型、重载、模板参数、参数表、约束、数据类型、单位、示例、芯片与版本范围。
2. 如果输入是链接，优先读取官方文档或源码仓中的一手材料；记录文档 URL、标题、版本、适用 SoC 和访问日期。若版本或 SoC 缺失，不猜测，在规格卡中标为 unresolved。
3. 定位目标页面的 `cann-vision/index-light.html`，并读取其中现有 API Visualizer 的入口、状态、派生函数、场景适配器、播放与代码生成实现。配送包中的默认位置是工作区根目录下的 `app/cann-vision/index-light.html`；若它已被复制到其他项目，以实际位置为准，不依赖原始仓库路径。
4. 读取本 skill 附带的 [PTO design-system 摘要](references/pto-design-system/README.md) 及将要消费的每个 `patterns/<id>/pattern.json`。至少检查 `ide-frame`；涉及矩阵或张量视图时同时检查 `tensor-title` 与对应的 `matrix-canvas` / `tensor-volume-canvas`；涉及播放时检查 `floating-playback-control`。这些参考资料位于 `references/pto-design-system/patterns/`，不要求目标环境另行安装 PTO design-system skill。
5. 需要理解现有黄金案例时，读取 [references/current-cases.md](references/current-cases.md)；黄金案例只用于提取行为和内容，不作为新的视觉母版。
6. 读取 [references/visual-system-contract.md](references/visual-system-contract.md)，建立公共 UI primitive 与当前页面实现的映射。

## 证据分级

给每条语义结论标记来源，不把推断包装成 API 事实：

- `documented`：函数原型、参数单位、范围、约束、布局、padding、stride 等由官方材料直接支持。
- `derived`：由 documented 规则计算出的 shape、地址区间、物理占用、窗口映射或时间线。
- `ux-model`：为帮助理解而设计的播放粒度、颜色、预设、阶段命名或聚合方式。
- `unresolved`：文档未说明、版本不明确或材料互相冲突，必须保留为待核实项。

Visualizer 是语义解释器，不是 cycle-accurate simulator。没有运行或 profiling 证据时，不展示真实 duration、pipeline overlap、吞吐、带宽或性能优劣结论。

## 工作流

### 1. 建立 API 规格卡

先复制并填写 [references/api-spec-template.md](references/api-spec-template.md)。规格卡必须覆盖：

- API 身份、函数族与所有需要支持的重载；
- 输入、输出、内存层级、dtype、format、shape 与地址空间；
- 每个参数的类型、单位、合法域、默认/示例值、作用对象和影响维度；
- 形状公式、地址公式、alignment / padding / stride / broadcast 规则；
- 参数依赖、互斥、条件启用、无几何影响但会影响代码或语义的参数；
- 适用芯片、CANN 版本、头文件或命名空间；
- 已知边界、非法状态与 unresolved 项。

原型与参数表不完整时，不进入实现。可先产出规格卡和待核实问题。

### 2. 选择可视化范式

按 API 的主要语义对象选视图，不按函数名猜 UI：

- 元素级计算：输入窗口 → 当前读集 → 输出写集，适合 1D/2D matrix 与 block 时间线。
- 数据搬运 / 对齐：源地址空间 → 搬运路径 → 目标地址空间，突出 valid、gap、padding、alignment、effective footprint。
- 滑窗 / layout transform：逻辑输入 → 物理布局 → 逻辑输出，突出坐标映射、窗口、padding、dilation、输出 shape。
- broadcast / reduce：源轴、扩展/归约轴、结果轴，突出哪些值来自存储、复制或聚合。
- 同步 / event：生产者、event 状态、消费者与等待关系；只有存在真实顺序语义时才使用 playback。
- Cube / MatMul 类：A/B/C 共享语义轴、tile、format 与搬运层级；多 Matrix Tensor 必须使用共享 source-unit scale。

一个 API 可组合多个 pattern，但每个 pane 都要回答一个明确问题。不要为了“信息完整”同时堆所有视图。

### 3. 先实现纯派生模型

遵循 [references/implementation-contract.md](references/implementation-contract.md)。先实现不读写 DOM 的函数：

1. `normalize(rawState)`：只做类型与基本范围归一化，保留用户输入值。
2. `derive(normalizedState)`：计算 shape、地址、segments、effective values、合法性、warnings。
3. `buildTimeline(derived)`：生成稳定、可寻址的语义步骤；静态 API 可省略。
4. `contextAtStep(derived, step)`：给出当前读、写、padding、完成集合和说明。
5. `toScenes(derived, context)`：转换为共享 pattern 的 business-neutral scene。
6. `toCode(normalizedState, derived, context)`：生成与当前参数一致的原型和调用示例。
7. `toExplanation(derived, context)`：生成公式、状态、warning 与无视觉影响参数说明。

不得让 Canvas、DOM、说明文案与代码生成各自重算一套业务规则。

若 UI 输入不合法，选择并明确一种处理方式：

- `reject`：保留输入并显示错误，不渲染误导性结果；或
- `normalize`：同时展示 requested 与 effective 值、修正规则和原因。

禁止静默改值后让生成代码使用另一个值。

### 4. 设计预设与测试矩阵

至少准备三类可区分语义的场景，而不是三个只改数字的示例：

- baseline：最小且容易解释的正常路径；
- structural variant：触发另一种布局、重载、padding、stride、broadcast 或 mode；
- boundary / invalid：触发对齐尾块、空输出、越界约束或版本限制。

每个预设记录：教学目标、参数、预期派生结果、必须出现的视觉信号、代码差异与来源证据。参数被手动修改后不再冒充某个预设。

### 5. 接入 CANN Vision

- 保持现有 `ide-frame` 页面 shell，案例只提供 domain state、controls、stage content 和 glue code。
- 优先 direct embedding 共享 pattern；不要复制 Canvas geometry、DPR、ResizeObserver、zoom、tooltip 或 playback chrome。
- 视觉 reference 必须来自公共 UI primitive，而不是某个 API 案例。优先复用 `viz-container`、`viz-container--matrix`、`tensor-title`、`api-selector`、`api-control-panel`、`api-control-group`、`api-field`、`api-choice-group`、`api-preset-group`、`api-stepper`、`api-select`、`api-help`、`api-hint`、`api-kv`、`api-kv-row`、`api-timeline`、`api-code-panel` 等系统契约；案例只提供数据、状态和业务 wrapper。
- 对外文档同时使用中文名称：可视化容器、矩阵可视化卡片、张量标题、API 案例选择器、API 控件面板、API 控件分组、API 参数字段、API 选项组、API 预设场景组、API 数值步进器、API 下拉选择、API 帮助提示、API 提示文本、API 键值检查器、API 语义时间线、API 代码面板；英文标识保留在 class / primitive map 中，避免实现与评审时产生歧义。
- 每个独立矩阵或张量视图都必须消费一份 `viz-container--matrix`，拥有独立背景卡片；多个矩阵的排列、连接箭头和间距属于业务布局 wrapper，不得把多个 canvas 合并到一个背景面板。
- 每个 `viz-container--matrix` 左上角必须 direct embedding `tensor-title`（中文名：张量标题），通过 `window.PtoTensorTitle.render(host, scene, options)` 传入结构化 label、shape、dtype、format、memory、state 与 status；矩阵卡片默认用 pattern 自带的 `density: 'compact'`，只有宽度与画布高度都足够且确实需要展开元数据时才用 `full`。案例不得手写标题 DOM、复制 pattern CSS、增加第二层 header/card，动态重渲染时必须 update 或 destroy 对应 controller。
- `api-stepper` 直接复用当前页面 `.stepper-control` 的公共几何：左减号 / 中间值 / 右加号三列，标签默认在上、控件在下；不要在 preview 或案例 CSS 中另造横排 stepper。
- 若公共 primitive 尚不存在，先在共享 design-system / pattern 层补齐 primitive，再由案例消费；不要把 primitive CSS 临时写进 API 页面，也不要把某个案例的私有 class 晋升为视觉规范。
- 每个新区域开始实现前，先提交 `primitive map`：语义角色、公共 primitive、允许的 domain wrapper、禁止的局部样式覆盖。没有 map 不进入 HTML/CSS 实现。
- `matrix-canvas` 用于精确 2D 行列关系；`tensor-volume-canvas` 用于固定视角 3D tensor；只有真实 step/time 语义时才用 `floating-playback-control`。
- 参数按用户任务分组，不机械照抄函数签名顺序。标签保留官方参数名，补充单位和一句影响说明。
- 对不改变几何但改变调用语义的参数，仍同步到代码和解释，并清楚注明“当前视图不变”。
- 添加 API selector、controls pane、stage pane、文档链接和案例注册时，保持统一键名；切换案例必须停止旧 timer、隐藏旧 playback，并清理 renderer controller。
- 新视觉能力只有在现有 pattern 无法表达时才进入 PTO preview gate；先扩共享 pattern，再由案例消费。

### 6. 保持六路联动

任何参数、预设或播放步骤变化后，检查以下输出是否来自同一状态：

1. 控件值与 enabled / disabled 状态；
2. shape、字节数、地址区间和公式；
3. Canvas / SVG scene；
4. timeline、当前读写与完成状态；
5. warning、解释和文档链接；
6. 函数原型与生成代码。

若某参数不会影响其中某一路，明确说明“不影响”，不要伪造视觉变化。

### 7. 验收

完成前执行 [references/implementation-contract.md](references/implementation-contract.md) 中的验收门。最低要求：

- 文档原型、参数名、单位与代码输出一致；
- 派生模型有 baseline、结构变体、边界/非法状态的可复算断言；
- 每个可调参数至少影响一个真实输出，或被标记为当前视图无影响；
- requested / effective 值没有被混淆；
- 预设、手动输入、API 切换、播放重置、主题切换和 resize 不产生残留状态；
- 使用离散步骤 playback 时，`Next` 在末步继续触发必须循环回首步，不能停留在末步形成无反馈点击；`Replay` 仍显式回到首步，自动播放到末步后仍停止；
- 公共 primitive 的 computed style 在不同 API 案例之间保持一致；案例不得通过局部 CSS 改写 primitive 的尺寸、间距、字体、边框、圆角或状态色；
- 矩阵粒度符合公共标准：能放下时优先调用 `matrix-canvas` 的 `createRealLayoutCells` 渲染真实 `1×1` cell（当前 demo 上限 256 个逻辑 cell）；只有超出可读性阈值才使用共享尺度的 aggregate cell，并在 UI 中明确标识；
- 每个矩阵/张量卡片左上角均由 `tensor-title` 渲染，标题 scene 与当前 shape、dtype、format、memory、step 和真实/聚合状态同步，页面中不存在案例私有的矩阵 header DOM 或失效 controller；
- 控件类型（selector、segmented choice、preset、stepper、select、help/hint、code action）和矩阵卡片在不同 API 案例中保持相同的 surface、padding、radius、gap 与状态表现；
- light / dark、窄宽度、键盘操作、tooltip/文本 fallback 可用；
- 页面没有宣称真实硬件时延或性能；
- 修改后进行本地浏览器交互检查，并记录已验证项与未验证项。

## 交付物

每次新增案例至少交付：

- 已填写的 API 规格卡；
- 文档事实 / 推导 / UX 模型 / unresolved 清单；
- 可视化范式与 pattern 选择理由；
- 参数联动表；
- 预设与测试矩阵；
- 页面实现；
- 验收结果和仍需官方材料或真实环境验证的项。

如果用户只要求方案而不要求写代码，交付前五项和实施切片，不修改页面。
